#!/bin/bash

# Title : b;eat 3.5 SPC Test Script (Final Revised)
# Author : Yunho Lee (yhlee@sdt.inc) / Modified by Assistant
# Date : 2025-12-14

# ==========================================
# SDT b;eat 3.5 SPC Test Script
# ==========================================

# 포트 정의
declare -a PORT0=( 'Thermal' '/dev/ttyS0' )
declare -a PORT1=( 'Coffee-L' '/dev/ttyS1' )
declare -a PORT2=( 'Coffee-R' '/dev/ttyS2' )
declare -a PORT3=( 'ICE-L' '/dev/ttyS3' )
declare -a PORT4=( 'ICE-R' '/dev/ttyS4' )

# 감지된 USB포트 ID를 저장할 배열
declare -a DETECTED_PORTS
declare -a PORT_DEVICE_NAMES

# 감지된 디스플레이 포트를 저장할 배열 (신규 추가)
declare -a DETECTED_DISPLAYS

# 설정: 테스트할 포트 총 개수
TARGET_USB_CNT=12
TARGET_DISPLAY_CNT=7  # 디스플레이 목표 개수 설정

# 로그 파일 이름 설정
START_TIME=$(date '+%Y-%m-%d %H:%M:%S')
FILE_DATE=$(date +%Y%m%d)
SERIAL_NO=$(cat /etc/hostname)

# 저장 경로 디렉토리 확인 및 생성
SAVE_DIR="/usr/local/beat/beat_spc_test"
if [ ! -d "$SAVE_DIR" ]; then
    mkdir -p "$SAVE_DIR"
fi
CSV_FILE="${SAVE_DIR}/spc_test_result_${FILE_DATE}_${SERIAL_NO}.csv"

err_flag=0

TEMP_LOG="/tmp/serial_test_recv.txt"

# 결과 저장 변수
RES_HOSTNAME=""
RES_CPU=""
RES_MB=""
# 추가된 결과 변수 (Storage, GPU)
declare -a RES_STORAGE_INFO
declare -a RES_GPU_INFO

RES_RAM_TOTAL=""
RES_RAM_SLOTS_TOTAL=""
RES_RAM_SLOTS_INSTALLED=""
declare -a RES_RAM_DETAILS_ARRAY

RES_USB_CNT=0
declare -a RES_USB_DEVICES

# 디스플레이 결과 변수 (수정됨)
RES_DISPLAY_CNT=0
declare -a RES_DISPLAY_PORTS

RES_SERIAL_COFFEE="N/A"
RES_SERIAL_ICE="N/A"
RES_SERIAL_THERMAL="N/A"

# 추가된 결과 변수 (LAN, FAN)
declare -a RES_LAN_INFO
declare -a RES_FAN_INFO

# 색상 코드 (출력용)
GREEN='\033[0;32m'
RED='\033[0;31m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# 루트 권한 확인
if [ "$EUID" -ne 0 ]; then
    echo -e "${RED}[Error] 이 스크립트는 루트 권한(sudo)으로 실행해야 합니다.${NC}"
    exit 1
fi

# ------------------- 기능 함수 정의 -------------------

# 시리얼 테스트
function serial_test() {
    local port1_name=$1
    local port1_dev=$2
    local port2_name=$3
    local port2_dev=$4
    local serial_speed=$5
    local current_err=0

    local TEST_MSG="TEST_DATA_${serial_speed}_bps_$(date '+%Y%m%d_%H%M%S')"

    echo "======================================================"
    echo "            RS-232C Loopback Test Start           "
    echo "   Connect: $1($2) <-> $3($4)   "
    echo "======================================================"

    echo -n "Testing Baudrate: $5 bps ... $1 -> $3 : "

    if [ ! -e "$2" ] || [ ! -e "$4" ]; then
        echo -e "${RED}FAIL (Device not found)${NC}"
        return 1
    fi

    stty -F $2 $serial_speed cs8 -cstopb -parenb -echo raw
    stty -F $4 $serial_speed cs8 -cstopb -parenb -echo raw

    rm -f $TEMP_LOG
    (timeout 2s cat $4 > $TEMP_LOG) &
    PID=$!

    sleep 0.5
    echo "$TEST_MSG" > $2
    wait $PID 2>/dev/null
    RECV_DATA=$(cat $TEMP_LOG)

    if [[ "$RECV_DATA" == *"$TEST_MSG"* ]]; then
        echo -e "${GREEN}OK${NC}"
        echo " -> Sent: $1 -- $TEST_MSG"
        echo " -> Recv: $3 -- $RECV_DATA"
    else
        echo -e "${RED}FAIL${NC}"
        echo " -> Sent: $1 -- $TEST_MSG"
        echo " -> Recv: $3 (No Data or Mismatch) -- '$RECV_DATA'"
        current_err=1
    fi
    
    echo "------------------------------------------------------"
    sleep 0.5

    echo -n "Testing Baudrate: $5 bps ... $3 -> $1 : "
    rm -f $TEMP_LOG
    (timeout 2s cat $2 > $TEMP_LOG) &
    PID=$!

    sleep 0.5
    echo "$TEST_MSG" > $4
    wait $PID 2>/dev/null
    RECV_DATA=$(cat $TEMP_LOG)

    if [[ "$RECV_DATA" == *"$TEST_MSG"* ]]; then
        echo -e "${GREEN}OK${NC}"
        echo " -> Sent: $3 -- $TEST_MSG"
        echo " -> Recv: $1 -- $RECV_DATA"
    else
        echo -e "${RED}FAIL${NC}"
        echo " -> Sent: $3 -- $TEST_MSG"
        echo " -> Recv: $1 (No Data or Mismatch) -- '$RECV_DATA'"
        current_err=2
    fi
    
    if [[ "$current_err" != "0" ]]; then
        echo -e "${RED}Error in Loopback Test${NC}"
        return 1
    fi
    
    echo "------------------------------------------------------"
    sleep 0.5
    return 0
}

# USB 포트 상태 화면 출력
function show_usb_status() {
    clear
    echo -e "${BLUE}======================================================${NC}"
    echo -e "     PC USB 포트 인식 테스트 (허브 제외 / 직결만)"
    echo -e "${BLUE}======================================================${NC}"
    
    echo -e "현재 감지된 개수: ${GREEN}${#DETECTED_PORTS[@]} / ${TARGET_USB_CNT}${NC}"
    echo -e "${RED}🛑 테스트를 멈추고 결과를 저장하려면 'q' 키를 누르세요.${NC}"
    echo -e "------------------------------------------------------"
    
    if [ ${#DETECTED_PORTS[@]} -eq 0 ]; then
        echo "아직 본체에 직접 연결된 유효 장치가 없습니다."
    else
        for i in "${!DETECTED_PORTS[@]}"; do
            echo -e "${GREEN}[✔] ${DETECTED_PORTS[$i]} -> ${PORT_DEVICE_NAMES[$i]}${NC}"
        done
    fi
    echo -e "------------------------------------------------------"
}

# USB 확인 로직
function usb_check() {
    show_usb_status

    while [ ${#DETECTED_PORTS[@]} -lt $TARGET_USB_CNT ]; do
        CURRENT_DEVICES=$(ls /sys/bus/usb/devices/ | grep -E '^[0-9]+-[0-9]+(\.[0-9]+)*$')
        UPDATED=false

        for dev_id in $CURRENT_DEVICES; do
            if [[ "$dev_id" == *"."* ]]; then continue; fi # 허브 제외

            skip=false
            for detected in "${DETECTED_PORTS[@]}"; do
                [[ "$detected" == "$dev_id" ]] && skip=true && break
            done

            if [[ "$skip" == "false" ]]; then
                PRODUCT_NAME=$(cat /sys/bus/usb/devices/$dev_id/product 2>/dev/null)
                PRODUCT_NAME=$(echo "$PRODUCT_NAME" | xargs)
                
                if [ -z "$PRODUCT_NAME" ] || [[ "$PRODUCT_NAME" == "Unknown Device" ]]; then
                    continue 
                fi
                DETECTED_PORTS+=("$dev_id")
                PORT_DEVICE_NAMES+=("$PRODUCT_NAME")
                UPDATED=true
            fi
        done

        if [ "$UPDATED" == "true" ]; then show_usb_status; fi

        read -t 1 -n 1 key_input
        if [[ "$key_input" == "q" || "$key_input" == "Q" ]]; then break; fi
    done
    
    RES_USB_CNT=${#DETECTED_PORTS[@]}
    RES_USB_DEVICES=("${PORT_DEVICE_NAMES[@]}")
    
    echo -e "${BLUE}USB 테스트 완료. (감지됨: $RES_USB_CNT)${NC}"
    sleep 1
}

# ------------------- 신규 추가 기능 -------------------

# 1. LAN 포트 점검 함수
function lan_check() {
    declare -a lan_interfaces
    declare -a lan_status
    lan_interfaces=($(ls /sys/class/net | grep -E '^(en|eth)'))
    
    for i in "${!lan_interfaces[@]}"; do lan_status[$i]=0; done

    while true; do
        clear
        echo -e "${BLUE}======================================================${NC}"
        echo -e "            유선 LAN 포트 연결 테스트"
        echo -e "${BLUE}======================================================${NC}"
        echo -e "검색된 LAN 인터페이스 수: ${#lan_interfaces[@]}"
        echo -e "각 포트에 랜선을 연결하여 'Link Up' 상태를 확인하세요."
        echo -e "${RED}🛑 테스트를 종료하려면 'q' 키를 누르세요.${NC}"
        echo -e "------------------------------------------------------"
        
        for i in "${!lan_interfaces[@]}"; do
            iface=${lan_interfaces[$i]}
            carrier_path="/sys/class/net/$iface/carrier"
            if [ -r "$carrier_path" ]; then
                link_state=$(cat "$carrier_path" 2>/dev/null)
            else
                link_state="0"
            fi

            if [[ "$link_state" == "1" ]]; then lan_status[$i]=1; fi

            if [[ "${lan_status[$i]}" == "1" ]]; then
                echo -e "Port: $iface \tStatus: ${GREEN}PASS (Connected)${NC}"
            else
                echo -e "Port: $iface \tStatus: ${YELLOW}Waiting for connection...${NC}"
            fi
        done
        echo -e "------------------------------------------------------"
        
        read -t 1 -n 1 key_input
        if [[ "$key_input" == "q" || "$key_input" == "Q" ]]; then break; fi
    done

    RES_LAN_INFO=()
    for i in "${!lan_interfaces[@]}"; do
        if [[ "${lan_status[$i]}" == "1" ]]; then
            RES_LAN_INFO+=("${lan_interfaces[$i]}:PASS")
        else
            RES_LAN_INFO+=("${lan_interfaces[$i]}:FAIL")
        fi
    done
    
    echo -e "${BLUE}LAN 테스트 완료.${NC}"
    sleep 1
}

# 2. 디스플레이 포트 점검 함수 (USB 방식과 유사하게 수정됨)
function show_display_status() {
    clear
    echo -e "${BLUE}======================================================${NC}"
    echo -e "            디스플레이 포트 인식 테스트 (DP/HDMI)"
    echo -e "${BLUE}======================================================${NC}"
    
    echo -e "현재 감지된 개수: ${GREEN}${#DETECTED_DISPLAYS[@]} / ${TARGET_DISPLAY_CNT}${NC}"
    echo -e "각 포트에 모니터를 연결하면 자동으로 감지됩니다."
    echo -e "${RED}🛑 테스트를 멈추고 결과를 저장하려면 'q' 키를 누르세요.${NC}"
    echo -e "------------------------------------------------------"
    
    if [ ${#DETECTED_DISPLAYS[@]} -eq 0 ]; then
        echo "아직 감지된 디스플레이 포트가 없습니다."
    else
        for i in "${!DETECTED_DISPLAYS[@]}"; do
            echo -e "${GREEN}[✔] Detected: ${DETECTED_DISPLAYS[$i]}${NC}"
        done
    fi
    echo -e "------------------------------------------------------"
}

function display_check() {
    DETECTED_DISPLAYS=()
    
    show_display_status

    while [ ${#DETECTED_DISPLAYS[@]} -lt $TARGET_DISPLAY_CNT ]; do
        # 디스플레이 커넥터 검색 (card0 기준, eDP/LVDS 등 내부 패널 제외)
        # /sys/class/drm/card*-* 경로 순회
        RAW_PORTS=$(ls -d /sys/class/drm/card*-* 2>/dev/null | grep -vE "(eDP|LVDS|Virtual)")
        
        UPDATED=false

        for p in $RAW_PORTS; do
            STATUS_FILE="$p/status"
            STATUS_FILE_VAR=$(cat $STATUS_FILE)
            TEMP_VAR=""
            # 연결 상태 확인
            if [[ -r "$STATUS_FILE" && "$STATUS_FILE_VAR" == "connected" ]]; then
                # 포트 이름 추출 (예: card0-HDMI-A-1 -> HDMI-A-1)
                PORT_NAME=$(basename "$p" | sed 's/^card[0-9]\+-//')
                TEMP_VAR=$(grep "connected" "$STATUS_FILE")
                
                # 이미 감지된 포트인지 중복 체크
                SKIP=false
                for detected in "${DETECTED_DISPLAYS[@]}"; do
                    [[ "$detected" == "$PORT_NAME" ]] && SKIP=true && break
                done
                
                if [[ "$SKIP" == "false" ]]; then
                    DETECTED_DISPLAYS+=("$PORT_NAME")
                    UPDATED=true
                fi
            fi
        done

        if [[ "$UPDATED" == "true" ]]; then
            show_display_status
        fi

        read -t 1 -n 1 key_input
        if [[ "$key_input" == "q" || "$key_input" == "Q" ]]; then
            break
        fi
    done

    # 결과 저장 (이름 배열 저장)
    RES_DISPLAY_CNT=${#DETECTED_DISPLAYS[@]}
    RES_DISPLAY_PORTS=("${DETECTED_DISPLAYS[@]}")

    echo -e "${BLUE}디스플레이 테스트 완료. (감지됨: $RES_DISPLAY_CNT)${NC}"
    sleep 1
}

# 3. 쿨링 팬 점검 함수
function fan_check() {
    clear
    echo -e "${BLUE}======================================================${NC}"
    echo -e "            시스템 쿨링 팬 상태 점검"
    echo -e "${BLUE}======================================================${NC}"
    
    RES_FAN_INFO=()
    hwmons=$(ls -d /sys/class/hwmon/hwmon* 2>/dev/null)
    found_fan=false
    
    for hw in $hwmons; do
        fan_inputs=$(ls $hw/fan*_input 2>/dev/null)
        for f in $fan_inputs; do
            found_fan=true
            fan_val=$(cat "$f")
            fname=$(basename "$f")
            idx=$(echo "$fname" | grep -o '[0-9]\+')
            
            pwm_file="$hw/pwm$idx"
            pwm_val="N/A"
            if [ -r "$pwm_file" ]; then pwm_val=$(cat "$pwm_file"); fi
            
            label_file="$hw/fan${idx}_label"
            fan_label="Fan $idx"
            if [ -r "$label_file" ]; then fan_label=$(cat "$label_file"); fi
            
            echo -e "Found $fan_label (hwmon): ${GREEN}$fan_val RPM${NC}, PWM: $pwm_val"
            RES_FAN_INFO+=("$fan_label ($fname)|$fan_val|$pwm_val")
        done
    done
    
    if [ "$found_fan" = false ]; then
        echo -e "${YELLOW}감지된 쿨링 팬 센서가 없습니다.${NC}"
        RES_FAN_INFO+=("No Fan Detected|0|0")
    fi
    echo -e "------------------------------------------------------"
    echo -e "팬 정보 기록 완료."
    sleep 2
}

# 최종 CSV 저장 함수 (행/열 전환)
function save_final_csv() {
    echo -e "\n${YELLOW}전체 테스트 결과 CSV 파일 생성 중...${NC}"

    # 1. 헤더 생성
    echo "Parameter,Value" > "$CSV_FILE"

    # 2. 데이터 행 생성
    echo "Date,\"$START_TIME\"" >> "$CSV_FILE"
    echo "Hostname,\"$RES_HOSTNAME\"" >> "$CSV_FILE"
    echo "CPU Model,\"$RES_CPU\"" >> "$CSV_FILE"
    echo "MainBoard,\"$RES_MB\"" >> "$CSV_FILE"
    
    # Storage
    local installed_storage_count=${#RES_STORAGE_INFO[@]}
    for ((i=0; i<installed_storage_count; i++)); do
        STORAGE_INFO="${RES_STORAGE_INFO[$i]}"
        STORAGE_INFO=${STORAGE_INFO//\"/\"\"}
        echo "Storage_$i,\"$STORAGE_INFO\"" >> "$CSV_FILE"
    done
    
    # GPU
    local installed_gpu_count=${#RES_GPU_INFO[@]}
    for ((i=0; i<installed_gpu_count; i++)); do
        GPU_DATA="${RES_GPU_INFO[$i]}"
        GPU_DATA=${GPU_DATA//\"/\"\"}
        echo "GPU_$i,\"$GPU_DATA\"" >> "$CSV_FILE"
    done
    
    # RAM
    echo "Total Memory,\"$RES_RAM_TOTAL\"" >> "$CSV_FILE"
    echo "Total RAM Slots,\"$RES_RAM_SLOTS_TOTAL\"" >> "$CSV_FILE"
    echo "Installed RAM Count,\"$RES_RAM_SLOTS_INSTALLED\"" >> "$CSV_FILE"
    
    local installed_ram_count=${#RES_RAM_DETAILS_ARRAY[@]}
    for ((i=0; i<installed_ram_count; i++)); do
        RAM_INFO="${RES_RAM_DETAILS_ARRAY[$i]}"
        RAM_INFO=${RAM_INFO//\"/\"\"}
        echo "RAM_Bank_$i,\"$RAM_INFO\"" >> "$CSV_FILE"
    done

    # USB
    echo "USB Detected Count,\"$RES_USB_CNT\"" >> "$CSV_FILE"
    for ((i=0; i<TARGET_USB_CNT; i++)); do
        local display_idx=$((i+1))
        if [ $i -lt ${#RES_USB_DEVICES[@]} ]; then
            DEVICE_NAME="${RES_USB_DEVICES[$i]}"
            DEVICE_NAME=${DEVICE_NAME//\"/\"\"}
            echo "USB_Device-$display_idx,\"$DEVICE_NAME\"" >> "$CSV_FILE"
        else
            echo "USB_Device-$display_idx,\"Not Detected\"" >> "$CSV_FILE"
        fi
    done
    
    # LAN
    for ((i=0; i<${#RES_LAN_INFO[@]}; i++)); do
        echo "LAN_Port_$i,\"${RES_LAN_INFO[$i]}\"" >> "$CSV_FILE"
    done
    
    # Display (수정됨: USB 방식과 유사하게 나열)
    echo "Display Detected Count,\"$RES_DISPLAY_CNT\"" >> "$CSV_FILE"
    for ((i=0; i<TARGET_DISPLAY_CNT; i++)); do
        local display_idx=$((i+1))
        if [ $i -lt ${#RES_DISPLAY_PORTS[@]} ]; then
            DISP_NAME="${RES_DISPLAY_PORTS[$i]}"
            echo "Display_Port-$display_idx,\"$DISP_NAME\"" >> "$CSV_FILE"
        else
            echo "Display_Port-$display_idx,\"Not Detected\"" >> "$CSV_FILE"
        fi
    done
    
    # Fan
    for ((i=0; i<${#RES_FAN_INFO[@]}; i++)); do
        idx=$((i+1))
        IFS='|' read -r f_name f_rpm f_pwm <<< "${RES_FAN_INFO[$i]}"
        echo "FAN_${idx}_Name,\"$f_name\"" >> "$CSV_FILE"
        echo "FAN_${idx}_RPM,\"$f_rpm\"" >> "$CSV_FILE"
        echo "FAN_${idx}_PWM,\"$f_pwm\"" >> "$CSV_FILE"
    done

    # Serial
    echo "Serial_Coffee(L-R),\"$RES_SERIAL_COFFEE\"" >> "$CSV_FILE"
    echo "Serial_ICE(L-R),\"$RES_SERIAL_ICE\"" >> "$CSV_FILE"
    echo "Serial_Thermal,\"$RES_SERIAL_THERMAL\"" >> "$CSV_FILE"
    
    echo -e "${BLUE}✅ 전체 결과가 저장되었습니다: $CSV_FILE${NC}"
}


# ------------------- 메인 실행 로직 -------------------

clear

echo -e "${BLUE}======================================================${NC}"
echo -e "               System Specification Check             "
echo -e "${BLUE}======================================================${NC}"

# Hostname
HOSTNAME=$(cat /etc/hostname)
echo -e "Hostname       : $HOSTNAME"
RES_HOSTNAME="$HOSTNAME"

# CPU
CPU_Model=$(cat /proc/cpuinfo | grep 'model name' | head -1 | awk -F': ' '{print $2}')
# MainBoard
MB_Model=$(sudo dmidecode -s baseboard-product-name)
echo -e "CPU Model      : $CPU_Model"
echo -e "MainBoard      : $MB_Model"
RES_CPU="$CPU_Model"
RES_MB="$MB_Model"

# Storage
echo -e "\nStorage Devices (fdisk based) :"
RES_STORAGE_INFO=()
raw_fdisk=$(LC_ALL=C sudo fdisk -l 2>/dev/null)
current_dev=""
current_size=""
current_model=""
current_interface="Unknown"

while IFS= read -r line; do
    if [[ "$line" =~ ^Disk\ /dev/ ]]; then
        if [[ -n "$current_dev" ]]; then
            if [[ ! "$current_dev" =~ ^/dev/loop && ! "$current_dev" =~ ^/dev/ram ]]; then
                if [ -z "$current_model" ]; then current_model="Unknown Model"; fi
                info_str="$current_model ($current_interface, $current_size)"
                echo -e "  - [$current_dev] $info_str"
                RES_STORAGE_INFO+=("$info_str")
            fi
        fi
        current_dev=$(echo "$line" | awk '{print $2}' | sed 's/://')
        current_model=""
        if [[ "$current_dev" == *"/nvme"* ]]; then current_interface="NVMe";
        elif [[ "$current_dev" == *"/sd"* ]]; then current_interface="SATA/USB";
        elif [[ "$current_dev" == *"/mmcblk"* ]]; then current_interface="eMMC";
        else current_interface="Generic"; fi
        bytes_str=$(echo "$line" | cut -d',' -f2 | awk '{print $1}')
        if [[ "$bytes_str" =~ ^[0-9]+$ ]]; then
             current_size=$(awk -v b="$bytes_str" 'BEGIN { printf "%.2f GB", b/1000000000 }')
        else
             current_size=$(echo "$line" | awk -F', ' '{print $1}' | awk -F': ' '{print $2}')
        fi
    elif [[ "$line" =~ ^Disk\ model: ]]; then
        current_model=$(echo "$line" | cut -d':' -f2 | xargs)
    fi
done <<< "$raw_fdisk"

if [[ -n "$current_dev" ]]; then
    if [[ ! "$current_dev" =~ ^/dev/loop && ! "$current_dev" =~ ^/dev/ram ]]; then
        if [ -z "$current_model" ]; then current_model="Unknown Model"; fi
        info_str="$current_model ($current_interface, $current_size)"
        echo -e "  - [$current_dev] $info_str"
        RES_STORAGE_INFO+=("$info_str")
    fi
fi

# GPU
echo -e "\nGraphic Cards (GPU) :"
RES_GPU_INFO=()
while read -r line; do
    if [[ "$line" =~ display[[:space:]]+(.+) ]]; then
        gpu_model="${BASH_REMATCH[1]}"
        echo -e "  - Found: $gpu_model"
        RES_GPU_INFO+=("$gpu_model")
    fi
done < <(sudo lshw -short -class display 2>/dev/null | grep -i display)
if [ ${#RES_GPU_INFO[@]} -eq 0 ]; then echo -e "  - No Graphic Card found or lshw failed."; fi

# Memory
TOTAL_MEM_CAP=$(sudo lshw -short -class memory 2>/dev/null | grep -vE 'BIOS|cache|RAM' | awk '/memory/{print $3}' | head -1)
echo -e "Total Memory   : $TOTAL_MEM_CAP"
RES_RAM_TOTAL="$TOTAL_MEM_CAP"

RAW_LSHW_FULL=$(sudo lshw -class memory 2>/dev/null)
RES_RAM_DETAILS_ARRAY=()
INSTALLED_CNT=0
while IFS='|' read -r status loc info; do
    if [[ "$status" == "INSTALLED" ]]; then
        INSTALLED_CNT=$((INSTALLED_CNT + 1))
        RES_RAM_DETAILS_ARRAY+=("[$loc] $info")
    else
        RES_RAM_DETAILS_ARRAY+=("[$loc] Empty Slot")
    fi
done < <(echo "$RAW_LSHW_FULL" | awk '
    BEGIN { in_bank = 0; }
    /^[ \t]*\*-/ { if (in_bank) { print_bank(); in_bank = 0; } }
    /\*-bank/ { if (in_bank) print_bank(); in_bank = 1; slot = "Unknown"; size = "Empty"; desc = ""; is_cache = 0; next; }
    in_bank {
        gsub(/^[ \t]+/, "", $0);
        if ($0 ~ /^description:/) { sub(/^description: /, "", $0); desc = $0; if (desc ~ /[Cc]ache/) is_cache = 1; }
        else if ($0 ~ /^slot:/) { sub(/^slot: /, "", $0); slot = $0; }
        else if ($0 ~ /^size:/) { sub(/^size: /, "", $0); size = $0; }
    }
    END { if (in_bank) print_bank(); }
    function print_bank() {
        if (is_cache == 1) return;
        if (size == "Empty" || desc ~ /empty/ || desc ~ /Empty/) { print "EMPTY|" slot "|Empty"; } 
        else { info = size " / " desc; print "INSTALLED|" slot "|" info; }
    }
')
TOTAL_SLOTS=${#RES_RAM_DETAILS_ARRAY[@]}
echo -e "Memory Slots   : $INSTALLED_CNT / $TOTAL_SLOTS (Installed / Total)"
RES_RAM_SLOTS_TOTAL="$TOTAL_SLOTS"
RES_RAM_SLOTS_INSTALLED="$INSTALLED_CNT"
echo -e "Memory Details :"
for ram_detail in "${RES_RAM_DETAILS_ARRAY[@]}"; do echo -e "  $ram_detail"; done
echo -e "------------------------------------------------------"

# 1. USB Test
echo -ne "\n\nUSB Port Test를 진행할까요(5초 대기)? [Y]n : "
read -t 5 user_input
if [ -z "$user_input" ]; then user_input="y"; fi
echo $user_input
sleep 1
if [[ "$user_input" =~ ^[Yy]$ ]]; then usb_check; else echo "USB 테스트 건너뜀."; RES_USB_CNT=0; fi

# 2. LAN Test
echo -ne "\n\n유선 LAN 포트 테스트를 진행할까요(5초 대기)? [Y]n : "
read -t 5 user_input
if [ -z "$user_input" ]; then user_input="y"; fi
echo $user_input
sleep 1
if [[ "$user_input" =~ ^[Yy]$ ]]; then lan_check; else echo "LAN 테스트 건너뜀."; RES_LAN_INFO=("Skipped"); fi

# 3. Display Test (수정됨)
echo -ne "\n\n디스플레이 포트 테스트를 진행할까요(5초 대기)? [Y]n : "
read -t 5 user_input
if [ -z "$user_input" ]; then user_input="y"; fi
echo $user_input
sleep 1
if [[ "$user_input" =~ ^[Yy]$ ]]; then display_check; else echo "디스플레이 테스트 건너뜀."; RES_DISPLAY_CNT=0; fi

# 4. Fan Test
echo -ne "\n\n쿨링 팬 상태 점검을 진행할까요(5초 대기)? [Y]n : "
read -t 5 user_input
if [ -z "$user_input" ]; then user_input="y"; fi
echo $user_input
sleep 1
if [[ "$user_input" =~ ^[Yy]$ ]]; then fan_check; else echo "팬 점검 건너뜀."; RES_FAN_INFO=("Skipped"); fi

# 5. Serial Test
echo -ne "\n\nDSUB-9 Serial Test를 진행할까요(5초 대기)? [Y]n : "
read -t 5 user_input
if [ -z "$user_input" ]; then user_input="y"; fi
echo $user_input
sleep 1
clear

if [[ "$user_input" =~ ^[Yy]$ ]]; then
    # Coffee
    echo -ne "\nCoffee Serial Test를 진행할까요? (Enter=Yes) [Y/n] : "
    read coffee_input
    if [ -z "$coffee_input" ]; then coffee_input="y"; fi
    if [[ "$coffee_input" =~ ^[Yy]$ ]]; then
        serial_test ${PORT1[0]} ${PORT1[1]} ${PORT2[0]} ${PORT2[1]} 115200
        if [ $? -eq 0 ]; then RES_SERIAL_COFFEE="PASS"; else RES_SERIAL_COFFEE="FAIL"; fi
    else echo "Coffee Serial Test 건너뜀."; RES_SERIAL_COFFEE="Skipped"; fi
    
    # Ice
    echo -ne "\nIce Serial Test를 진행할까요? (Enter=Yes) [Y/n] : "
    read ice_input
    if [ -z "$ice_input" ]; then ice_input="y"; fi
    if [[ "$ice_input" =~ ^[Yy]$ ]]; then
        serial_test ${PORT3[0]} ${PORT3[1]} ${PORT4[0]} ${PORT4[1]} 115200
        if [ $? -eq 0 ]; then RES_SERIAL_ICE="PASS"; else RES_SERIAL_ICE="FAIL"; fi
    else echo "Ice Serial Test 건너뜀."; RES_SERIAL_ICE="Skipped"; fi
    
    # Thermal
    echo -ne "\nThermal <-> Ice-R Serial Test를 진행할까요? (Enter=Yes) [Y/n] : "
    read thermal_input
    if [ -z "$thermal_input" ]; then thermal_input="y"; fi
    if [[ "$thermal_input" =~ ^[Yy]$ ]]; then
        serial_test ${PORT0[0]} ${PORT0[1]} ${PORT4[0]} ${PORT4[1]} 115200
        if [ $? -eq 0 ]; then RES_SERIAL_THERMAL="PASS"; else RES_SERIAL_THERMAL="FAIL"; fi
    else echo "Thermal Serial Test 건너뜀."; RES_SERIAL_THERMAL="Skipped"; fi
else
    echo "시리얼 테스트 건너뜀."
fi

save_final_csv
sudo sh -c "echo '1' > /usr/local/beat/FirstTest" root
echo "모든 테스트가 완료되었습니다."