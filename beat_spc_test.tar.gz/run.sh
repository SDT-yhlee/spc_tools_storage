#!/bin/bash

# Script for running SDT b;eat 3.5 Test Script.

clear

# 색상 코드 (출력용)
GREEN='\033[0;32m'
RED='\033[0;31m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

BEAT_PATH="/usr/local/beat"
SCRIPT_PATH="${BEAT_PATH}/beat_spc_test"


FIRST_TEST=""
cur_hostname=""
cur_hostname=$(cat /etc/hostname)

if [ -d $BEAT_PATH ]; then
    if [ -d $SCRIPT_PATH ]; then
        echo -e "<< ${SCRIPT_PATH} 경로가 존재합니다 ! >>\n"
    else
        sudo mkdir $SCRIPT_PATH
    fi
    if [ -e "${BEAT_PATH}/FirstTest" ]; then
        FIRST_TEST=$(cat ${BEAT_PATH}/FirstTest)
    else
        sudo sh -c "echo -n '1' > $BEAT_PATH/FirstTest" root
        FIRST_TEST=$(cat $BEAT_PATH/FirstTest)
    fi
else
    sudo mkdir $BEAT_PATH
    sudo sh -c "echo -n '1' > $BEAT_PATH/FirstTest" root
    FIRST_TEST=$(cat $BEAT_PATH/FirstTest)
    sudo mkdir $SCRIPT_PATH
fi

if [ -e "beat_spc_test.sh" ]; then
    chmod +x "beat_spc_test.sh"
    sudo mv beat_spc_test.sh "${SCRIPT_PATH}"
    echo "테스트 환경을 구성합니다."
else
    if [ -e "${SCRIPT_PATH}/beat_spc_test.sh" ]; then
        echo "테스트 환경을 구성합니다."
    else
        echo "테스트 스트립트에 오류가 있습니다. 처음부터 다시 시작하십시오."
    fi
fi

sleep 1

if [ "${FIRST_TEST}" == "1" ]; then
        echo -e "\n초기 설정이 필요합니다."
        echo -e "현재 S/N : ${cur_hostname}"
        echo -ne "b;eat 3.5 SPC의 S/N을 입력하세요 : "
        read Serial
        echo -e "입력된 S/N : < ${Serial} >"
        sleep 1
        sudo sh -c "echo '${Serial}' > /etc/hostname" root
        cur_hostname=$(cat /etc/hostname)
        echo -e "현재  S/N : < ${cur_hostname} >"
        sleep 1
        echo "b;eat 3.5 SPC Test 를 시작합니다 !"
        sleep 2
    else
        echo "시리얼 번호가 이미 설정되어 있습니다 !"
        echo -e "현재  S/N : < ${cur_hostname} >"
        sleep 1
        echo "b;eat 3.5 SPC Test 를 시작합니다 !"
        sleep 2
    fi
sudo $SCRIPT_PATH/beat_spc_test.sh
EXIT_CODE=$?
if [ "$EXIT_CODE" == 0 ]; then
    # sudo chown $USER:$USER $SCRIPT_PATH/*.csv
    if [ -d "/mnt/usb_temp" ]; then
        echo -e "${YELLOW}/mnt/usb_temp 경로가 존재합니다.${NC}"
    else
        sudo mkdir /mnt/usb_temp
    fi
    if [ -e "/dev/disk/by-path/pci-0000:00:14.0-usb-0:1:1.0-scsi-0:0:0:0-part1" ]; then
        sudo umount /dev/disk/by-path/pci-0000:00:14.0-usb-0:1:1.0-scsi-0:0:0:0-part1 
        echo -e "${GREEN}USB 1번 장치 마운트 중...${NC}"
        sleep 1
        sudo mount /dev/disk/by-path/pci-0000:00:14.0-usb-0:1:1.0-scsi-0:0:0:0-part1 /mnt/usb_temp
        echo -e "${YELLOW}결과 파일을 USB 1번 포트 저장 장치에 저장 중${NC}"
        sudo cp $SCRIPT_PATH/*.csv /mnt/usb_temp/
        echo -e "${YELLOW}USB 1번 포트 저장 장치 해제 중...${NC}"
        sudo umount /dev/disk/by-path/pci-0000:00:14.0-usb-0:1:1.0-scsi-0:0:0:0-part1
        sudo rm -r /mnt/usb_temp
        # sudo rm $SCRIPT_PATH/*.csv
        echo -e "${GREEN}USB 1번 포트 저장 장치에 기록파일 저장이 완료되었습니다!${NC}"
        echo "run.sh 스크립트를 3초 후 자체 삭제합니다."
        sudo cp ./run.sh $SCRIPT_PATH   # 만약을 대비해 /usr/local/beat/beat_spc_test 경로에 복사
        (sleep 3 && rm -- "$0") &
    else
        echo -e "${RED}USB 1번 포트에 메모리 카드가 없습니다!${NC}"
    fi
else
    echo "테스트 중 오류가 발생했습니다"
fi
rm beat_spc_test.tar.gz
