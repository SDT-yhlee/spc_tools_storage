#!/bin/bash

## Author : yhlee (Device Team at SDT Inc.)
## Date : 2025. 04. 26
# Log : Add commect color for improve visibility.

## Shell Script for Uninstall APC UPS Daemon.

## Stop daemon
## remove APC UPS Daemon from autostart and delete service.
# echo -e '\033[33m''Stop apcupsd service and disable...''\033[0m'
# sudo /etc/init.d/apcupsd stop
# sudo systemctl disable apcupsd.service

## Install APC UPS Daemon
echo -e '\033[33m''<< Remove apcupsd package >>''\033[0m'
sudo apt purge apcupsd -y && sudo apt autoremove --purge -y

## Add udev rules. UPS USB port will linked with fixed name --> [/dev/ttyUPS] 
echo -e '\033[33m''Remove udev rules file...''\033[0m'
sudo rm /etc/udev/rules.d/APCUPS.rules 

## Reload udev rules daemon.
echo -e '\033[33m''Reload udev rules services...''\033[0m'
sudo service udev reload
sudo service udev restart

sudo systemctl daemon-reload

echo -e '\033[33m''Uninstall apcupsd complete !''\033[0m'
