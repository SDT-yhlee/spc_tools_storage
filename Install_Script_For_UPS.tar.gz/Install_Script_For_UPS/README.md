UPS 설치 스크립트 설명 (2025.03.26 yhlee @ SDT Inc. DX Device Team)

### 1. 파일 설명

    1) APCUPS.rules

    - SRV2KI-E 장치의 vendor id, product id 와 동일한 USB 연결될 경우 'ttyUPS' 이름으로 심링크 생성시키도록 하는 udev 서비스 규칙파일


    2) apcupsd

    - apcupsd 서비스 실행여부를 결정하는 파일. 기본값은 no 임. 기 설정된 apcupsd.conf 파일이 설치되므로 yes로 변경된 파일을 설치하여 서비스가 실행될 수 있도록 변경


    3) apcupsd.conf

    - UPS의 동작 설정 파일. 아래 변경된 부분 기재

     : UPSCABLE         USB

     : UPSTYPE          apcsmart

     : DEVICE           /dev/ttyUPS

     : ONBATTERYDELAY   6

     : BATTERYLEVEL     10

     : MINUTES          3

     : TIMEOUT          180

     : ANNOY            120

     : ANNOYDELAY       60

     : KILLDELAY        0

     : UPSNAME          UPS_BEAT

     : OUTPUTVOLTS      220


    4) install_apcupsd.sh

    APC UPS Daemon 설치 스크립트. apt를 이용해 apcupsd 패키지 설치 및 아래 과정 수행

    a. apcupsd.conf 파일을 특정 경로에 복사

    b. apcupsd 파일을 특정 경로에 복사

    c. APCUPS.rules 파일을 특정 경로에 복사

    d. udev 서비스 재시작

    e. UPS 장치 USB 케이블 재연결 요청 메세지 출력

    f. apcupsd 서비스 시작

    g. apcaccess 명령을 통해 UPS 상태 조회

### 2. 사용법

    sudo ./install_apcupsd.sh
