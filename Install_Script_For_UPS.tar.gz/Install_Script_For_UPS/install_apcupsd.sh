#!/bin/bash

## Author : yhlee (Device Team at SDT Inc.)
## Date : 2025. 04. 26
# Log : Add commect color for improve visibility.

## Shell Script for Install APC UPS Daemon.

## Install APC UPS Daemon
echo -e '\033[33m''<< Install apcupsd package >>''\033[0m'
sudo apt update > /dev/null 2>&1 && sudo apt install apcupsd -y > /dev/null 2>&1

# Find UPS's USB Port from kernel dmesg
#str=$(dmesg | grep "xr_serial converter now attached to ttyUSB")
#echo $str
#if [ -n "$str" ]; then
#    echo -e '\033[33m'Found UPS USB Port!''\033[0m'
#    UPS_PORT="${str#*to }"
#    echo -e '\033[33m'UPS UBS Port = $UPS_PORT''\033[0m'
#    str="DEVICE /dev/ttyUSB."
#    PORT="DEVICE /dev/${UPS_PORT}"
#
#    sed -i "s%$str%$PORT%" apcupsd.conf
#else
#    echo -e '\033[33m'Cannot find UPS USB Port!''\033[0m'
#fi

## Copy configure files
## These configure files operate in USB cable connection with SRV2KI-E environment.
echo -e '\033[33m''Copy configuration files...''\033[0m'
sudo cp apcupsd.conf /etc/apcupsd/
sudo cp apcupsd /etc/default/

## Add udev rules. UPS USB port will linked with fixed name --> [/dev/ttyUPS] 
echo -e '\033[33m''Copy udev rules file...''\033[0m'
sudo cp APCUPS.rules /etc/udev/rules.d/

## Reload udev rules daemon.
echo -e '\033[33m''Reload udev rules services...''\033[0m'
sudo service udev reload
sudo service udev restart

## For proper operate, disconnect UPS USB cable and re-connect the USB Cable.
echo -ne '\033[33m''For proper operate << Reconnect UPS USB Cable ! >> and press Enter ...!''\033[0m'
read

## Start daemon

## Add APC UPS Daemon autostart at boot and add service.
echo -e '\033[33m''Start apcupsd service and wait 3s...''\033[0m'
sudo systemctl enable apcupsd.service
sleep 1
sudo systemctl daemon-reload
sudo /etc/init.d/apcupsd start
sleep 1
sudo systemctl restart apcupsd.service

## Check APC UPS Daemon works properly and UPS informations.
sleep 7
apcaccess
echo -e '\033[33m''Install UPS tool completed !''\033[0m'
