# SPC GPIO Control tool.

### Author: yhlee @SDT Inc. DX Device Team

## Folder Structure:

    ├── GPIO_Driver         GPIO Driver for SPC Mainboard.

    │   ├── conf

    │   ├── driver

    │   ├── install.sh

    │   ├── Makefile

    │   └── uninstall.sh

    ├── README.md

    └── service             GPIO Control Service. If shutdown or reboot, GPIO 0 set to Low for SMPS Power Off.

        ├── gpiochip_ctl.service
        
        └── gpiochip_ctl.sh

## Usage: 

### Install SPC GPIO TOOL:

* sudo ./install_spc_gpio.sh

### Uninstall SPC GPIO TOOL:

* sudo ./uninstall_spc_gpio.sh
