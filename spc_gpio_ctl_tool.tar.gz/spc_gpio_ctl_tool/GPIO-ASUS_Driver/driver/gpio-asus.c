// SPDX-License-Identifier: GPL-2.0-or-later
/*
 * ASUS GPIO driver
 * Copyright (c) 2022, ASUS Ltd.
 *
 * Author: Kunyang Fan <kunyang_fan@asus.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */
#include <linux/bitops.h>
#include <linux/delay.h>
#include <linux/gpio/driver.h>
#include <linux/init.h>
#include <linux/io.h>
#include <linux/module.h>
#include <linux/platform_device.h>

#define DRVNAME "gpio_asus"

#define PMIO_CONFIG_SPACE_ADDR 0xCF8
#define PMIO_CONFIG_SPACE_DATA 0xCFC
#define TARGET_PCI_BUS 0x00
#define TARGET_PCI_DEV 0x1F
#define TARGET_PCI_FUNC 0x04

struct asus_gpio_bank
{
	struct gpio_chip chip;
	unsigned long regbase;
	struct asus_gpio_data *data;
};

struct asus_gpio_data
{
	int nr_bank;
	struct asus_gpio_bank *bank;
	unsigned long pmio_base_reg;
};

static int asus_gpio_get_direction(struct gpio_chip *chip,
								   unsigned int offset);
static int asus_gpio_output_set_direction(struct gpio_chip *chip,
										  unsigned int offset, int value);
static int asus_gpio_input_set_direction(struct gpio_chip *chip,
										 unsigned int offset);
static int asus_gpio_get(struct gpio_chip *chip,
						 unsigned int offset);
static void asus_gpio_set(struct gpio_chip *chip, unsigned int offset,
						  int value);

#define ASUS_GPIO_BANK(_base, _ngpio, _regbase)                 \
	{                                                           \
		.chip = {                                               \
			.label = DRVNAME,                                   \
			.owner = THIS_MODULE,                               \
			.get_direction = asus_gpio_get_direction,           \
			.direction_input = asus_gpio_input_set_direction,   \
			.direction_output = asus_gpio_output_set_direction, \
			.get = asus_gpio_get,                               \
			.set = asus_gpio_set,                               \
			.base = _base,                                      \
			.ngpio = _ngpio,                                    \
			.can_sleep = true,                                  \
		},                                                      \
		.regbase = _regbase,                                    \
	}

static struct asus_gpio_bank asus_gpio_bank_info[] = {
	ASUS_GPIO_BANK(0, 0, 0x00),
};

static u8 smbus_read_one_byte(unsigned long base_addr, u8 reg)
{
	u8 status, val, cmd;
	int i;

	status = inb(base_addr + 0x00);
	outb(status, base_addr + 0x00); // SMBus Clear Status
	outb(0x08, base_addr + 0x02);	// Set SMBus CMD to Byte Data
	outb(0x41, base_addr + 0x04);	// Set SMBus Slave Address to 0x20 and excute Read flow
	outb(reg, base_addr + 0x03);	// Set SMBus Reg
	cmd = inb(base_addr + 0x02);
	cmd = cmd | 0x40;
	outb(cmd, base_addr + 0x02); // Excute SMBus Command

	status = inb(base_addr + 0x00); // Get SMBus Status
	i = 0;
	while (!(status & 0x8E) && (i++ < 100))
	{ // Wait for SMBus finished command
		mdelay(1);
		status = inb(base_addr + 0x00);
		i++;
	}

	val = inb(base_addr + 0x05); // Get SMBus Data
	return val;
}

static int smbus_write_one_byte(unsigned long base_addr, u8 reg, u8 data)
{
	u8 status, cmd;
	int i;

	status = inb(base_addr + 0x00);
	outb(status, base_addr + 0x00); // SMBus Clear Status
	outb(0x08, base_addr + 0x02);	// Set SMBus CMD to Byte Data
	outb(0x40, base_addr + 0x04);	// Set SMBus Slave Address to 0x20 and excute Read flow
	outb(reg, base_addr + 0x03);	// Set SMBus Reg
	outb(data, base_addr + 0x05);	// Set SMBus Data
	cmd = inb(base_addr + 0x02);
	cmd = cmd | 0x40;
	outb(cmd, base_addr + 0x02); // Excute SMBus Command

	status = inb(base_addr + 0x00); // Get SMBus Status
	i = 0;
	while (!(status & 0x8E) && (i++ < 100))
	{ // Wait for SMBus finished command
		mdelay(1);
		status = inb(base_addr + 0x00);
		i++;
	}

	return i > 100 ? -1 : 0;
}

static int asus_gpio_get_direction(struct gpio_chip *chip, unsigned int offset)
{
	int retval;
	struct asus_gpio_bank *bank = container_of(chip, struct asus_gpio_bank, chip);
	unsigned long base_reg = bank->regbase;
	u8 direction_mask;

	direction_mask = smbus_read_one_byte(base_reg, 0x00);
	retval = direction_mask & (0x01 << offset);
	return retval > 0 ? 1 : 0;
}

static int asus_gpio_input_set_direction(struct gpio_chip *chip,
										 unsigned int offset)
{
	struct asus_gpio_bank *bank = container_of(chip, struct asus_gpio_bank, chip);
	unsigned long base_reg = bank->regbase;
	u8 direction_mask;

	direction_mask = smbus_read_one_byte(base_reg, 0x00);
	direction_mask |= (0x01 << offset);

	return smbus_write_one_byte(base_reg, 0x00, direction_mask);
}

static int asus_gpio_output_set_direction(struct gpio_chip *chip,
										  unsigned int offset, int value)
{
	struct asus_gpio_bank *bank = container_of(chip, struct asus_gpio_bank, chip);
	unsigned long base_reg = bank->regbase;
	u8 direction_mask;

	direction_mask = smbus_read_one_byte(base_reg, 0x00);
	direction_mask &= (~(0x01 << offset));

	return smbus_write_one_byte(base_reg, 0x00, direction_mask);
}

static int asus_gpio_get(struct gpio_chip *chip, unsigned int offset)
{
	u8 retval;
	struct asus_gpio_bank *bank = container_of(chip, struct asus_gpio_bank, chip);
	unsigned long base_reg = bank->regbase;
	u8 direction_mask;

	direction_mask = smbus_read_one_byte(base_reg, 0x09);

	retval = direction_mask & (0x01 << offset);

	return retval > 0 ? 1 : 0;
}

static void asus_gpio_set(struct gpio_chip *chip, unsigned int offset,
						  int value)
{
	struct asus_gpio_bank *bank = container_of(chip, struct asus_gpio_bank, chip);
	unsigned long base_reg = bank->regbase;
	u8 direction_mask;

	direction_mask = smbus_read_one_byte(base_reg, 0x0A);
	if (value > 0)
		direction_mask |= (0x01 << offset);
	else
		direction_mask &= ~(0x01 << offset);

	smbus_write_one_byte(base_reg, 0x0A, direction_mask);
}

static int asus_gpio_probe(struct platform_device *pdev)
{
	int err, i;
	struct asus_gpio_data *data;
	struct asus_gpio_bank *bank;

	data = (struct asus_gpio_data *)dev_get_platdata(&pdev->dev);
	if (!data)
		return -ENOMEM;

	data->nr_bank = ARRAY_SIZE(asus_gpio_bank_info);
	data->bank = asus_gpio_bank_info;

	bank = &data->bank[0];
	bank->chip.parent = &pdev->dev;
	bank->chip.ngpio = 8;
	bank->regbase = data->pmio_base_reg;
	bank->data = data;
	err = devm_gpiochip_add_data(&pdev->dev, &bank->chip, bank);
	if (err)
		pr_debug("Failed to register gpiochip %d: %d\n", i, err);

	// gpio 0 value Set to 1 when module loaded to kernel.  -- 2025.04.28 yhlee @ SDT Inc. DX Device Team
	struct gpio_chip *spc_gpio_chip = &bank->chip;
	asus_gpio_output_set_direction(spc_gpio_chip, 0, 1);
	asus_gpio_set(spc_gpio_chip, 0, 1);
	pr_info("GPIO 0 set to Output and Value High");
	return err;
}

static int asus_gpio_remove(struct platform_device *pdev)
{
	// do nothing
	return 0;
}

static struct platform_driver asus_gpio_driver = {
	.driver = {
		.owner = THIS_MODULE,
		.name = DRVNAME,
	},
	.probe = asus_gpio_probe,
	.remove = asus_gpio_remove,
};

static struct platform_device *asus_gpio_pdev = NULL;

static int __init asus_gpio_device_add(const struct asus_gpio_data *data)
{
	int err;

	asus_gpio_pdev = platform_device_alloc(DRVNAME, -1);
	if (!asus_gpio_pdev)
	{
		pr_err(DRVNAME ": Error platform_device_alloc\n");
		return -ENOMEM;
	}

	err = platform_device_add_data(asus_gpio_pdev,
								   data, sizeof(*data));
	if (err)
	{
		pr_err(DRVNAME "Platform data allocation failed\n");
		goto err;
	}

	err = platform_device_add(asus_gpio_pdev);
	if (err)
	{
		pr_err(DRVNAME "Device addition failed\n");
		goto err;
	}
	pr_info(DRVNAME ": Device added\n");
	return 0;

err:
	platform_device_put(asus_gpio_pdev);

	return err;
}

static int __init asus_gpio_init(void)
{
	int err;
	struct asus_gpio_data data;
	unsigned long val, reg;

	val = 0x80000000 |
		  (TARGET_PCI_BUS << 16) |
		  (TARGET_PCI_DEV << 11) |
		  (TARGET_PCI_FUNC << 8) |
		  0x20;
	outl(val, 0xCF8);
	val = inw(0xCFC);
	reg = val & 0x0000FFE0;

	pr_info("pmio register:0x%X\n", (unsigned int)reg);
	if (reg == 0)
		return -ENODEV;

	data.pmio_base_reg = reg;

	err = platform_driver_register(&asus_gpio_driver);
	if (!err)
	{
		pr_info(DRVNAME ": platform_driver_register\n");
		err = asus_gpio_device_add(&data);
		if (err)
			platform_driver_unregister(&asus_gpio_driver);
	}

	return err;
}
subsys_initcall(asus_gpio_init);

static void __exit asus_gpio_exit(void)
{
	platform_device_unregister(asus_gpio_pdev);
	platform_driver_unregister(&asus_gpio_driver);
}
module_exit(asus_gpio_exit);

MODULE_DESCRIPTION("ASUS GPIO Driver");
MODULE_AUTHOR("Kunyang Fan <Kunyang_Fan@asus.com>");
MODULE_LICENSE("GPL v2");
