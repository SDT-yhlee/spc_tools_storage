#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/export-internal.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

#ifdef CONFIG_UNWINDER_ORC
#include <asm/orc_header.h>
ORC_HEADER;
#endif

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif



static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0x3d8ee50d, "platform_driver_unregister" },
	{ 0xf0fdf6cb, "__stack_chk_fail" },
	{ 0xf07d9d2a, "platform_device_unregister" },
	{ 0x4c9c72c9, "devm_gpiochip_add_data_with_key" },
	{ 0x2cf56265, "__dynamic_pr_debug" },
	{ 0xbdfb6dbb, "__fentry__" },
	{ 0x5b8239ca, "__x86_return_thunk" },
	{ 0xeae3dfd6, "__const_udelay" },
	{ 0xa648e561, "__ubsan_handle_shift_out_of_bounds" },
	{ 0x122c3a7e, "_printk" },
	{ 0xe4cfdada, "__platform_driver_register" },
	{ 0x84448c4d, "platform_device_alloc" },
	{ 0xdad94be4, "platform_device_add_data" },
	{ 0x42618eb7, "platform_device_add" },
	{ 0xaacf5dea, "platform_device_put" },
	{ 0xf079b8f9, "module_layout" },
};

MODULE_INFO(depends, "");


MODULE_INFO(srcversion, "FBE60D12EA99C0D2501F31D");
