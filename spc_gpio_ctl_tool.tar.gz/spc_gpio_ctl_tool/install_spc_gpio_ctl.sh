#!/bin/bash

# Author : yhlee @ SDT Inc. DX Device Team
# Date : 2025-04-28
# Title : Install Script for SPC GPIO Control
# Required : Ubuntu 22.04.5 LTS, Kernel: 6.8.0-XX (Tested on 6.8.0-57)

MB_model=$(sudo dmidecode -s baseboard-product-name)
K_ver=$(uname -r)
ver_name="${K_ver%%-generic*}"

# Check Mainboard Model.
# Q670EA-IM-A : SDT Beat Mainboard
# H610I-IM-A : ECN 2U, 4U Mainboard

### Install GPIO CHIP Driver
# Install essential package.
echo -e '\033[33m''<< Install GPIO Chip Driver... >>''\033[0m'
echo -e '\033[33m''<< Install essential packages for build driver... >>''\033[0m'
sudo apt update > /dev/null 2>&1 && sudo apt install gcc-12 build-essential make \
    linux-hwe-6.8-headers-${ver_name} linux-hwe-6.8-tools-${ver_name} -y > /dev/null 2>&1
echo -e '\033[33m''<< Install GPIO Driver ... >>''\033[0m'

if [ ${MB_model} == "Q670EA-IM-A" ]; then
    echo -e '\033[33m''<< Q670EA-IM-A Mainboard detected ! >>''\033[0m'
    ### Install Driver
    cd GPIO-ASUS_Driver
    sudo ./install.sh
    if [ $? -eq 0 ]; then
        echo -e '\033[33m''<< gpio_asus driver install complete ! >>''\033[0m'
    else
        echo -e '\033[31m''<< Driver install Failed... Tool install stopped... >>''\033[0m'
        exit 1
    fi
    cd ..

elif [ ${MB_model} == "H610I-IM-A" ]; then
    echo -e '\033[33m''<< H610I-IM-A Mainboard detected ! >>''\033[0m'
    ### Install Driver
    cd GPIO_Driver
    sudo ./install.sh
    if [ $? -eq 0 ]; then
        echo -e '\033[33m''<< nct6116d driver install complete ! >>''\033[0m'
    else
        echo -e '\033[31m''<< Driver install Failed... Tool install stopped... >>''\033[0m'
        exit 1
    fi
    cd ..
    
    # # Install gpiod package.
    # echo -e '\033[33m''<< Install gpiod package for gpio control... >>''\033[0m'
    # sudo apt install gpiod -y

else
    echo -e '\033[31m''<< Not Supported Mainboard. Install aborted... >>''\033[0m'
    exit 1
fi

### Install Service
echo -e '\033[33m''<< Install SPC GPIO Control Service... >>''\033[0m'

# Set permission to Service script and copy to system folder.
echo -e '\033[33m''<< Set Permission to service files >>''\033[0m'
chmod 755 ./service/spc_gpiochip_ctl.sh
echo -e '\033[33m''<< Copy service file to /etc/systemd/system/ path ... >>''\033[0m'
sudo cp ./service/spc_gpiochip_ctl.service /etc/systemd/system/
echo -e '\033[33m''<< Copy Service script file to /usr/local/beat/spc_gpiochip_ctl path ... >>''\033[0m'
if [ -d "/usr/local/beat" ]; then
    if [ -d "/usr/local/beat/spc_gpiochip_ctl" ]; then
        sudo cp ./service/spc_gpiochip_ctl.sh /usr/local/beat/spc_gpiochip_ctl/
    else
        mkdir /usr/local/beat/spc_gpiochip_ctl
        sudo cp ./service/spc_gpiochip_ctl.sh /usr/local/beat/spc_gpiochip_ctl/
    fi
else
    mkdir /usr/local/beat
    mkdir /usr/local/beat/spc_gpiochip_ctl
    sudo cp ./service/spc_gpiochip_ctl.sh /usr/local/beat/spc_gpiochip_ctl/
fi    
# sudo cp ./service/spc_gpiochip_ctl.sh /usr/sbin/

# system control daemon reload.
sudo systemctl daemon-reload
sudo systemctl enable spc_gpiochip_ctl.service

echo -e '\033[33m''<< Install SPC GPIO Control tool complete! >>''\033[0m'
