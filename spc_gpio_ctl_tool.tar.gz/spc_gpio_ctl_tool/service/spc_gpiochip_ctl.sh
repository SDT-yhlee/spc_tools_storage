#!/bin/bash

# Author : yhlee @ SDT Inc. QX Device 1 Team
# Date : 2025-07-08
# Title : SPC GPIO Control Script for GPIO control service(spc_gpiochip_ctl.service)
# Required : Ubuntu 22.04.5 LTS, Kernel: 6.8.0-XX (Tested on 6.8.0-57)

# Define Variables
gpiosyspath="/sys/class/gpio"
delimiter="gpiochip"
# label="gpio_asus"
label="cp210x"

# Define Functions
GPIO_ENABLE() {
  if [ ! -d "$gpiosyspath/gpio$1" ]; then
    echo "Enable GPIO $gpionum ...!" 
    sh -c "echo $gpionum > $gpiosyspath/export" root
  else
    echo "GPIO $gpionum already enabled !"
  fi
  sleep 0.05
}

GPIO_DISABLE() {
  if [ -d "$gpiosyspath/gpio$1" ]; then
    echo "Disable GPIO $1 ...!" 
    sh -c "echo $gpionum > $gpiosyspath/unexport" root
  else
    echo "GPIO $1 already disabled !"
  fi
  sleep 0.05
}

GPIO_OUT() {
  if [ ! -d "$gpiosyspath/gpio$1" ]; then
    echo "Set GPIO $1 enable first!"
  else
    echo "Set GPIO $1 direction to output!"
    sh -c "echo out > $gpiosyspath/gpio$1/direction" root
  fi
  # cat $gpiosyspath/gpio$1/direction
  sleep 0.05
}

GPIO_IN() {
  if [ ! -d "$gpiosyspath/gpio$1" ]; then
    echo "Set GPIO $1 enable first!"
  else
    echo "Set GPIO $1 direction to input!"
    sh -c "echo in > $gpiosyspath/gpio$1/direction" root
  fi  
  # cat $gpiosyspath/gpio$1/direction
  sleep 0.05
}

GPIO_HIGH() {
  if [ ! -d "$gpiosyspath/gpio$1" ]; then
    echo "Set GPIO $1 enable first!"
  else
    if [ "$(cat $gpiosyspath/gpio$1/direction)" = "out" ]; then
      echo "Set GPIO $1 to High(1)"  
      sh -c "echo 1 > $gpiosyspath/gpio$1/value" root
      # cat $gpiosyspath/gpio$1/value
    else
      echo "Set GPIO $1 set to Output first!"
    fi
  fi
  
}

GPIO_LOW() {
  if [ ! -d "$gpiosyspath/gpio$1" ]; then
    echo "Set GPIO $1 enable first!"
  else
    if [ "$(cat $gpiosyspath/gpio$1/direction)" = "out" ]; then
      echo "Set GPIO $1 to High(1)"  
      sh -c "echo 0 > $gpiosyspath/gpio$1/value" root
      # cat $gpiosyspath/gpio$1/value
    else
      echo "Set GPIO $1 set to Output first!"
    fi
  fi
  sleep 0.05
}

### Main ###

MB_model=$(sudo dmidecode -s baseboard-product-name)
sleep 1
if [ ${MB_model} == "Q670EA-IM-A" ] || [ ${MB_model} == "H610I-IM-A" ]; then
    find $gpiosyspath -maxdepth 1 -name "*gpiochip*" | while read -r dir; do
        # echo "$dir"
        dev_label=$(cat $dir/label)
        dir_length=${#dir}
        # echo $dir_length
        if [ ${dir_length} -lt 1 ]; then
            echo "No such device to control !"
        else
            if [ "$dev_label" = "$label" ]; then

            chipnumber=$(echo "$dir" | awk -F "$delimiter" '{print $2}')
            
            # GPIO 0, 2, 4, 6 control
            for i in $(seq 0 3); do
                gpionum=$(expr $chipnumber + 2 \* $i)
                GPIO_ENABLE $gpionum
                GPIO_OUT $gpionum
                GPIO_HIGH $gpionum
                GPIO_DISABLE $gpionum
            done

            # for i in $(seq 0 3); do
            #   gpionum=$(expr $chipnumber + 2 \* $i)
            #   # GPIO_IN $gpionum
            #   GPIO_HIGH $gpionum
            #   GPIO_DISABLE $gpionum
            # done
            else
              echo "$dir is not $label device !"
            fi
        fi
    done
    sleep 2
    if [ ! -d "/sys/class/gpio/gpio0" ]; then
        sh -c "echo 'Add GPIO 0 to gpio path...'" root
        sh -c "echo 0 > /sys/class/gpio/export" root
    fi
    sh -c "echo 0 > /sys/class/gpio/gpio0/value" root
    echo $(date +"%Y-%m-%d_%H:%M:%S --- Electric SMPS Off !")

else
    echo -e '\033[31m''<< Not Supported Mainboard. Install aborted... >>''\033[0m'
    exit 1
fi

