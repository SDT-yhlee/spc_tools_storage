#!/bin/bash

MB_model=$(sudo dmidecode -s baseboard-product-name)
sleep 3
if [ ${MB_model} == "Q670EA-IM-A" ] || [ ${MB_model} == "H610I-IM-A" ]; then
    if [ ! -d "/sys/class/gpio/gpio0" ]; then
        sh -c "echo 'Add GPIO 0 to gpio path...'" root
        sh -c "echo 0 > /sys/class/gpio/export" root
    fi
    sh -c "echo 0 > /sys/class/gpio/gpio0/value" root
    echo $(date +"%Y-%m-%d_%H:%M:%S --- Electric SMPS Off !")

else
    echo -e '\033[31m''<< Not Supported Mainboard. Install aborted... >>''\033[0m'
    exit 1
fi

