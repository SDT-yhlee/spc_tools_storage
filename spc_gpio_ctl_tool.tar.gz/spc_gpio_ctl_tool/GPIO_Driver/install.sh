#/bin/bash

title()
{
    echo -----------------------------------------
    echo "Install GPIO Driver."
    echo -----------------------------------------
}

show_usage()
{
    echo "install.sh\n"
}

title

echo "Check gpio driver and unload it."
check=`lsmod | grep -w gpio_nct6116d`
if [ "$check" != "" ]; then
	echo "rmmod gpio-nct6116d"
    /sbin/rmmod gpio-nct6116d
fi

echo "Build the module and install."
echo "-------------------------------" >> log.txt
date 1>>log.txt
make all 1>>log.txt || exit 1

OLD_DRIVER=$(find /lib/modules/$(uname -r)/kernel/drivers/gpio -iname gpio-nct6116d.ko -type f)
BAK_DRIVER=$(find /lib/modules/$(uname -r)/kernel/drivers/gpio -iname gpio-nct6116d.ko_bak -type f)
TARGET_PATH=/lib/modules/$(uname -r)/kernel/drivers/gpio

if [ "$BAK_DRIVER" = "" ]; then
    if [ "$OLD_DRIVER" = "" ]; then
        cp driver/gpio-nct6116d.ko $TARGET_PATH/
    else
        mv $OLD_DRIVER $TARGET_PATH/gpio-nct6116d.ko_bak
        cp driver/gpio-nct6116d.ko $TARGET_PATH/
    fi
else
    cp driver/gpio-nct6116d.ko $TARGET_PATH/
fi

echo "Update driver."
depmod -a


echo "Load module: gpio_nct6116d."
modprobe gpio_nct6116d


#Add modprobe to init

echo "Add driver to init."

cp conf/gpio-nct6116d.conf /etc/modules-load.d/

echo "Completed."
exit 0


