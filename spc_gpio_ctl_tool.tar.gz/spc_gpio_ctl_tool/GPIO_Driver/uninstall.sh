#/bin/bash

title()
{
	echo -----------------------------------------
	echo "Un-install GPIO Driver."
	echo -----------------------------------------
}

show_usage()
{
    echo "uninstall.sh\n"
}

title

echo "Check installed driver and unload it."
check=`lsmod | grep -w gpio_nct6116d`
if [ "$check" != "" ]; then
	echo "rmmod gpio-nct6116d."
	/sbin/rmmod gpio-nct6116d
fi

echo "Remove the module..."
OLD_DRIVER=$(find /lib/modules/$(uname -r)/kernel/drivers/gpio -iname gpio-nct6116d.ko -type f)
if [ "$OLD_DRIVER" = "" ]; then
    echo "No need to remove kernel module!"
else
    rm $OLD_DRIVER
    echo "Update driver."
    depmod -a
fi


FILE="/etc/modules-load.d/gpio-nct6116d.conf"
if [ -f "$FILE" ]; then
    echo "Remove the file $FILE!"
    rm $FILE
fi


echo "Completed."
exit 0


