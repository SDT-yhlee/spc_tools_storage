#!/bin/bash

# Author : yhlee @ SDT Inc. DX Device Team
# Date : 2025-04-28
# Title : Uninstall Script for SPC GPIO Control

MB_model=$(sudo dmidecode -s baseboard-product-name)
K_ver=$(uname -r)
ver_name='${K_ver%%-generic*}'

### Uninstall Service
echo -e '\033[33m''<< Uninstall SPC GPIO Control Service... >>''\033[0m'

# system control daemon remove.
# sh -c "echo 0 > /sys/class/gpio/unexport" root
sudo systemctl disable spc_gpiochip_ctl.service
sudo systemctl daemon-reload

echo -e '\033[33m''<< Delete service file from /etc/systemd/system/ path ... >>''\033[0m'
sudo rm /etc/systemd/system/spc_gpiochip_ctl.service
echo -e '\033[33m''<< Delete Service script file from /usr/local/beat/spc_gpiochip_ctl/ path ... >>''\033[0m'
sudo rm -r /usr/local/beat/spc_gpiochip_ctl/

# Uninstall gpiod package.
if [ ${MB_model} == "Q670EA-IM-A" ]; then
    echo -e '\033[33m''<< Q670EA-IM-A Mainboard detected ! >>''\033[0m'
    ### Uninstall Driver
    echo -e '\033[33m''<< Uninstall GPIO Driver ... >>''\033[0m'
    cd GPIO-ASUS_Driver
    sudo ./uninstall.sh
    cd ..   

elif [ ${MB_model} == "H610I-IM-A" ]; then
    echo -e '\033[33m''<< H610I-IM-A Mainboard detected ! >>''\033[0m'
    echo -e '\033[33m''<< Uninstall gpiod package for gpio control... >>''\033[0m'
    # sudo apt purge gpiod -y

    ### Uninstall Driver
    echo -e '\033[33m''<< Uninstall GPIO Driver ... >>''\033[0m'
    cd GPIO_Driver
    sudo ./uninstall.sh
    cd ..
else
    echo -e '\033[31m''<< Not Supported Mainboard. Uninstall aborted... >>''\033[0m'
    exit 1
fi

# Uninstall essential package. (Don't used)
# echo -e '\033[33m''<< Uninstall essential packages for build driver... >>''\033[0m'
# sudo apt purge gcc-12 build-essential make -y
# sudo apt autoremove --purge -y
# linux-hwe-6.8-headers-${ver_name} linux-hwe-6.8-tools-${ver_name} -y
# leave 2 kernel tools to prepare for any problems.

echo -e '\033[33m''<< Uninstall SPC GPIO Control tool complete! >>''\033[0m'